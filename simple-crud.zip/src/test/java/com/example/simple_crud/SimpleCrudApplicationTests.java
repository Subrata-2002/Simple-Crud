package com.example.simple_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
