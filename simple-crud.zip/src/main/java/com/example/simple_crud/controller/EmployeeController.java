package com.example.simple_crud.controller;

import com.example.simple_crud.dto.EmployeeDto;
import com.example.simple_crud.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController // Rest controller is used to handle HTTP requests
@RequestMapping("/api/employee")
@AllArgsConstructor

public class EmployeeController{
private EmployeeService employeeService;

//build add Employee Rest Api
    @PostMapping
    public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto){
    EmployeeDto savedEmployee = employeeService.createEmployee(employeeDto);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }


}
