package com.example.simple_crud.service;

import com.example.simple_crud.dto.EmployeeDto;

public interface EmployeeService {
    //here the EmployeeDto  is used to transfer data between layers
     EmployeeDto createEmployee(EmployeeDto employeeDto);
}
