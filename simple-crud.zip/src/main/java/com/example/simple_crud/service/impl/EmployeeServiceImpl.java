package com.example.simple_crud.service.impl;

import com.example.simple_crud.dto.EmployeeDto;
import com.example.simple_crud.entity.Employee;
import com.example.simple_crud.mapper.EmployeeMapper;
import com.example.simple_crud.repository.EmployeeRepository;
import com.example.simple_crud.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        //here we consvert the employeeDto entity to employeeJpa entity
        //now lets save the employeeJpa entity to the database
      Employee savedEmployee =  employeeRepository.save(employee);// here we pass the employeeJpa entity to the repository save method

        return EmployeeMapper.mapToEmployeeDto(savedEmployee);

    }
}
